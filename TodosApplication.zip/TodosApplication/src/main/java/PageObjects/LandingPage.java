package PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

/**
 * @author Ruchi Tiwari
 *
 */

public class LandingPage {
	
	WebDriver driver;
	
	By Heading=By.tagName("h1");
	By AddTodo=By.cssSelector("input[placeholder='What needs to be done?']"); 
	By ListCount=By.xpath("//span[@class='todo-count']/strong");
	By ClearCompleted=By.className("clear-completed");
	
	
	public LandingPage(WebDriver driver)
	{
		this.driver=driver;
	}
	
	public WebElement getItemCheckbox(int index)
	{
		return driver.findElement(By.xpath("//ul[@class='todo-list']/li["+index+"]/div/input"));
	}
	public WebElement getItemText(int index)
	{
		return driver.findElement(By.xpath("//ul[@class='todo-list']/li["+index+"]/div/label"));
	}
	public WebElement getItemDelete(int index)
	{
		return driver.findElement(By.xpath("//ul[@class='todo-list']/li["+index+"]/div/button"));
	}
	public WebElement getHeading()
	{
		return driver.findElement(Heading);
	}
	
	public WebElement getAddTodo()
	{
		return driver.findElement(AddTodo);
	}
	
	public WebElement getListCount()
	{
		return driver.findElement(ListCount);
	}
	
	public WebElement getClearCompleted()
	{
		return driver.findElement(ClearCompleted);
	}
}
