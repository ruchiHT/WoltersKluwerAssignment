package stepDefinitions;

import java.io.IOException;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import PageObjects.LandingPage;
import WoltersKluwer.TodosApplication.base;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class stepDefinition extends base{
	
	public WebDriver driver;
	public LandingPage lp;
	
	@Given("^User initializes the browser$")
	public void User_initializes_the_browser() throws IOException
	{
		driver=initializeDriver(); // Invoking the browser by calling base class method
	}
	
	 @When("^User launches the \"([^\"]*)\" todo application URL$")
	    public void user_launches_the_something_todo_application_url(String strArg1) throws Throwable {
		 
		 driver.get(strArg1); // Launching the application
	    }


    @Then("^Verify the heading of the landing page$")
    public void verify_the_heading_of_the_landing_page() throws Throwable {
    	
    	lp=new LandingPage(driver); // creating landing page object
    	
    	// verifying the heading of landing page
		Assert.assertEquals(lp.getHeading().getText(), "todos"); 
		
    }
    
    @When("^User creates list of todo items$")
    public void user_creates_list_of_todo_items() throws Throwable {
    	
    	lp=new LandingPage(driver);
		
    	//Adding 4 items in the todo list
		for(int i=1;i<=4;i++)
		{
			lp.getAddTodo().sendKeys("TestData"+i);
			lp.getAddTodo().sendKeys(Keys.ENTER);
		}
        
    }

    @Then("^Verify the item count is displayed correctly$")
    public void verify_the_item_count_is_displayed_correctly() throws Throwable {
    	
    	lp=new LandingPage(driver);
    	//verifying the count of items in todo list
    	Assert.assertEquals(lp.getListCount().getText(), "4");
    }

      
    @And("^User launches the \"([^\"]*)\" application URL$")
    public void user_launches_the_something_application_url(String strArg1) throws Throwable {
    	
    	driver.get(strArg1); //launching the application
    }

    
    @Then("^User clicks on remove button and Verify the item is removed and item count is decreased$")
    public void user_clicks_on_remove_button_and_verify_the_item_is_removed_and_item_count_is_decreased() throws Throwable {
    	
    	lp=new LandingPage(driver);
    	
    	//verifying the count of items in todo list
    	Assert.assertEquals(lp.getListCount().getText(), "4");
    	
    	//Fetching the text of the 2nd item from the list before deleting
		String itemTextBefore=lp.getItemText(2).getText();
		
		//click on the remove button
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", lp.getItemDelete(2));
		
		//Fetching the text of the 2nd item from the list before deleting
		String itemTextAfter=lp.getItemText(2).getText();
		
		//verify the items, before and after deleting from 2nd position are not matching 
		Assert.assertNotEquals(itemTextAfter, itemTextBefore);
		
		//verifying the count of items in todo list is decreased now
		Assert.assertEquals(lp.getListCount().getText(), "3");
		
    }

  
    
    @And("^User completes a todo item from list$")
    public void user_completes_a_todo_item_from_list() throws Throwable {
       
    	lp=new LandingPage(driver);
		lp.getItemCheckbox(2).click(); //completing 2nd item from the list
		
    }
    
    @Then("^User clicks on clear completed button and verifies the completed item gets cleared$")
    public void user_clicks_on_clear_completed_button_and_verifies_the_completed_item_gets_cleared() throws Throwable {
       
    	lp=new LandingPage(driver);
		
      //Fetching the count of items in todo list after completing but before clearing
    	String itemTextBefore=lp.getItemText(2).getText();
    	
    	//verifying the item count after completing but before clearing
		Assert.assertEquals(lp.getListCount().getText(), "3");
		
		lp.getClearCompleted().click();	//Clearing the completed 2nd item from the list	
		
		 //Fetching the count of items in todo list after completing and clearing
		String itemTextAfter=lp.getItemText(2).getText();
		
		//verifying the item count after completing and clearing
		Assert.assertEquals(lp.getListCount().getText(), "3");
		
		//verify the items before and after clearing them from 2nd position are not matching
		Assert.assertNotEquals(itemTextAfter, itemTextBefore);
    	
    }

    
    @And("^User edits the item and update it to blank$")
    public void user_edits_the_item_and_update_it_to_blank() throws Throwable {
    	
    	lp=new LandingPage(driver);
		
		//double click for edit and delete the text and update it to blank
		Actions action=new Actions(driver);
		action.doubleClick(lp.getItemText(2)).perform();
		action.doubleClick().build().perform();
		action.sendKeys(Keys.DELETE);
				
		
		
    }

    @Then("^Blank item list is not created$")
    public void blank_item_list_is_not_created() throws Throwable {
    	
    	lp=new LandingPage(driver);
    	
    	//verify the item at 2nd index is blank
    	Assert.assertEquals(lp.getItemText(2).getText(), "");
    }

    @When("^User inputs nothing and hits enter key$")
    public void user_inputs_nothing_and_hits_enter_key() throws Throwable {
    	 
    	lp=new LandingPage(driver);
		  
    	//creating blank item 
		lp.getAddTodo().sendKeys("");
		lp.getAddTodo().sendKeys(Keys.ENTER);
		
    }

    @Then("^Blank item is not created and item count is not displayed$")
    public void blank_item_is_not_created_and_item_count_is_not_displayed() throws Throwable {
    	
    	lp=new LandingPage(driver);
    	
    	//verify item count is invisible 
    	boolean present;
		try {
			   WebDriverWait wait=new WebDriverWait(driver,2);
			   wait.until(ExpectedConditions.invisibilityOf(lp.getListCount()));
			   present = true;
			} catch (NoSuchElementException e) {
			   present = false;
			}
		
		//verifies that item count is not present
		Assert.assertFalse(present);
		   
    }

    @Then("^Clear completed button is not visible$")
    public void clear_completed_button_is_not_visible() throws Throwable {

       lp=new LandingPage(driver);
       
      //verify clear completed button is invisible 
		boolean present;
		try {
			WebDriverWait wait=new WebDriverWait(driver,2);
			   wait.until(ExpectedConditions.invisibilityOf(lp.getClearCompleted()));
			    present = true;
			} catch (NoSuchElementException e) {
			   present = false;
			}
		
		//verifies that clear completed is not present
		Assert.assertFalse(present);
		
    }
   
    @Then("^User refreshes the page and Verifies all the items are present and item count is not changed$")
    public void user_refreshes_the_page_and_verifies_all_the_items_are_present_and_item_count_is_not_changed() throws Throwable {
    	
    	lp=new LandingPage(driver);
		
    	//fetch item count before refresh
    	String countBefore=lp.getListCount().getText();
    	
    	//refresh the page
		driver.navigate().refresh();
		
		//fetch item count after refresh
		String countAfter=lp.getListCount().getText();
		
		//veify item count is same before and after refresh
		Assert.assertEquals(countBefore, countAfter);
		
    }
    
    
    @And("^User closes the browser$")
    public void user_closes_the_browser() throws Throwable {
    	
    	driver.close(); //close the browser
    }



}
