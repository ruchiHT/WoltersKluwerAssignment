package WoltersKluwer.TodosApplication;

import java.io.IOException;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import PageObjects.LandingPage;
import WoltersKluwer.TodosApplication.base;

public class PositiveTestCases extends base {
	
	public WebDriver driver;
	@BeforeMethod
	public void initialize() throws IOException
	{
		driver=initializeDriver();
		driver.get(prop.getProperty("url"));
		
	}
	
	@Test
	public void validateLanding()
	{
		LandingPage lp=new LandingPage(driver);
		//System.out.println(lp.getHeading().getText());
		Assert.assertEquals(lp.getHeading().getText(), "todos");
		
	}
	

	@Test
	public void clearCompleted() throws InterruptedException
	{
		LandingPage lp=new LandingPage(driver);
		//Adding 4 items in the todo list
		for(int i=0;i<=3;i++)
		{
			lp.getAddTodo().sendKeys("One"+i);
			lp.getAddTodo().sendKeys(Keys.ENTER);
		}
		
		lp.getItemCheckbox(2).click(); //completing 2nd item from the list
		String itemTextBefore=lp.getItemText(2).getText();
		
		
		Assert.assertEquals(lp.getListCount().getText(), "3");
		lp.getClearCompleted().click();	//Clearing the completed 2nd item from the list	
		String itemTextAfter=lp.getItemText(2).getText();
		Assert.assertEquals(lp.getListCount().getText(), "3");
		Assert.assertNotEquals(itemTextAfter, itemTextBefore);
		
	}
	
	@Test
	public void countItems()
	{
		LandingPage lp=new LandingPage(driver);
			
		//adding items to the list
		for(int i=0;i<=3;i++)
		{
			lp.getAddTodo().sendKeys("One"+i);
			lp.getAddTodo().sendKeys(Keys.ENTER);
		}
		Assert.assertEquals(lp.getListCount().getText(), "4");
		
	}
	
	@Test
	public void removeItems() throws InterruptedException
	{
		LandingPage lp=new LandingPage(driver);
		//adding items to the list
		for(int i=0;i<=2;i++)
		{
			lp.getAddTodo().sendKeys("One"+i);
			lp.getAddTodo().sendKeys(Keys.ENTER);
		}
		Assert.assertEquals(lp.getListCount().getText(), "3");
		String itemTextBefore=lp.getItemText(2).getText();
		
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", lp.getItemDelete(2));
		String itemTextAfter=lp.getItemText(2).getText();
		Assert.assertNotEquals(itemTextAfter, itemTextBefore);
		Assert.assertEquals(lp.getListCount().getText(), "2");
			
	}

	
	@AfterMethod
	public void teardown()
	{
		driver.close();
	}


}
