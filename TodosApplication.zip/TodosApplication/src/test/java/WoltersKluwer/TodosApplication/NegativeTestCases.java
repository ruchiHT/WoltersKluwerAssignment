package WoltersKluwer.TodosApplication;

import java.io.IOException;


import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import PageObjects.LandingPage;
import WoltersKluwer.TodosApplication.base;

public class NegativeTestCases extends base {
	public WebDriver driver;
	@BeforeMethod
	public void initialize() throws IOException
	{
		driver=initializeDriver();
		driver.get(prop.getProperty("url"));
		
	}
	
	@Test
	public void VerifyBlankListCreation()
	{
		
		LandingPage lp=new LandingPage(driver);
		  
		lp.getAddTodo().sendKeys("");
		lp.getAddTodo().sendKeys(Keys.ENTER);
		boolean present;
		try {
			   WebDriverWait wait=new WebDriverWait(driver,2);
			   wait.until(ExpectedConditions.invisibilityOf(lp.getListCount()));
			   present = true;
			} catch (NoSuchElementException e) {
			   present = false;
			}
		
		Assert.assertFalse(present);
		
	}
	
	@Test
	public void clearCompletedForIncompleteList()
	{
		LandingPage lp=new LandingPage(driver);
		//Adding 4 items in the todo list
				for(int i=0;i<=3;i++)
				{
					lp.getAddTodo().sendKeys("One"+i);
					lp.getAddTodo().sendKeys(Keys.ENTER);
				}
		boolean present;
		try {
			WebDriverWait wait=new WebDriverWait(driver,2);
			   wait.until(ExpectedConditions.invisibilityOf(lp.getClearCompleted()));
			    present = true;
			} catch (NoSuchElementException e) {
			   present = false;
			}
		
		Assert.assertFalse(present);
		
	}
	
	@Test
	public void editListBlank()
	{
		LandingPage lp=new LandingPage(driver);
		//Adding 4 items in the todo list
		for(int i=0;i<=3;i++)
		{
			lp.getAddTodo().sendKeys("One"+i);
			lp.getAddTodo().sendKeys(Keys.ENTER);
		}
		//String item=lp.getItemText(2).getText();
		Actions action=new Actions(driver);
		action.doubleClick(lp.getItemText(2)).perform();
		action.doubleClick().build().perform();
		action.sendKeys(Keys.DELETE);
				
		Assert.assertEquals(lp.getItemText(2).getText(), "");
		
	}
	
	@Test
	public void VerifyPageRefreshing()
	{
		LandingPage lp=new LandingPage(driver);
		for(int i=0;i<=2;i++)
		{
			lp.getAddTodo().sendKeys("One"+i);
			lp.getAddTodo().sendKeys(Keys.ENTER);
		}
		String countBefore=lp.getListCount().getText();
		driver.navigate().refresh();
		String countAfter=lp.getListCount().getText();
		Assert.assertEquals(countBefore, countAfter);
		
	}

	
	@AfterMethod
	public void teardown()
	{
		driver.close();
	}


}
